"""Storage adapters."""
