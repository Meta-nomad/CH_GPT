"""TradingView chart selector bot."""
