# TradingView Chart Selector Bot

Telegram-бот выбирает лучший TradingView-график криптовалюты для анализа.

## Финальная логика выбора

1. Бот ищет USD/USDT-графики на популярных биржах в формате TradingView.
2. История и качество считаются только по свечам TradingView.
3. Длина истории проверяется крупно: `1M`, `1W`, `1D`.
4. Качество проверяется отдельно на часовых свечах.
5. Если TradingView не отдал свечи по рынку, рынок не попадает в основной рейтинг.
6. Биржевые OHLCV больше не используются как доказательство истории TradingView.
7. Для монет, появившихся после массового появления USDT, рабочий USDT-график имеет приоритет над USD.
8. Для старых активов USD может победить, если дает существенно более длинную историю.
9. MEXC Futures проверяется отдельно по живому фьючерсному рынку `BASE_USDT`: ticker + стакан.

## Что оценивается

- Длина истории TradingView.
- Пара USD/USDT с политикой приоритета USDT для post-USDT монет.
- Разрывы на часовых свечах.
- Плоские свечи.
- Нулевой объем.
- Подозрительные скачки цены.
- Средний часовой объем TradingView как дополнительный tie-break.
- Наличие живого фьючерсного рынка на MEXC.

## Биржи

Основные TradingView-кандидаты строятся для популярных бирж: Binance, Bybit, OKX, MEXC, Bitget, Gate.io, KuCoin, Kraken, Bitfinex, Coinbase, Crypto.com, Gemini, Bitstamp.

## Команды

- `/start` - краткая подсказка.
- `BTC` - найти лучший график.
- `/why BTC` - то же, что обычный запрос, но явной командой.
- `/compare BTC` - топ до 10 вариантов.
- `/tvtest BTC` - диагностика TradingView-свечей по найденным символам.
- `/mexc BTC` - диагностика MEXC Futures по точному рынку `BTC_USDT`.

## Запуск локально

1. Создай бота у BotFather и получи токен.
2. Скопируй `.env.example` в `.env`.
3. Заполни `BOT_TOKEN`.
4. Установи зависимости: `pip install -r requirements.txt`.
5. Запусти: `python -m app.main`.

## Деплой на Railway

1. Загрузи проект на GitHub.
2. Создай Railway-проект из GitHub-репозитория.
3. Добавь переменную окружения `BOT_TOKEN`.
4. Railway использует `Dockerfile` и запускает `python -m app.main`.

## Диагностика

Проверка TradingView из терминала:

```bash
python tools/tv_probe.py BITGET:KAIAUSDT MEXC:KAIAUSDT OKX:KAIAUSDT --interval 1D --limit 5
```

Проверка MEXC в Telegram:

```text
/mexc MORPHO
```

Если внешний источник недоступен, бот должен вернуть `не удалось проверить`, а не ложное `Да`.

## Алиасы тикеров и котировок

Бот учитывает переименования и разные формы записи котировки:

- `RENDER` / `RNDR`.
- `POL` / `MATIC`.
- `KAIA` / `KLAY`.
- `BEAM` / `BEAMX`.
- `G` / `GAL`.
- `XNO` / `NANO`.
- `BTT` / `BTTOLD`.
- `LUNC` / `LUNA`.
- `USDT` = `TetherUS` = `Tether US` = `Tether USD` = `Tether`.
- `USD` = `US Dollar` = `Dollar`.

Для таких случаев бот ищет не только `BASE`, но и полные варианты `BASEUSDT`, `BASEUSD`, а также варианты старого тикера, например `RNDRUSDT` для `RENDER`.
